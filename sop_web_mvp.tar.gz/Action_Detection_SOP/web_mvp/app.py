from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional
import re
from dataclasses import dataclass
from datetime import datetime, date as Date

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from .auth import BasicAuthConfig, BasicAuthMiddleware, issue_session_token
from .review_store import ReviewRecord, get_review, get_reviews_by_uid, init_db, upsert_review
from .session_index import SessionArtifact, SessionIndex
from .settings import WebMvpSettings


def _display_status(value: str) -> str:
    # Render "NOT_DONE" as "NOT DONE" to match UI labels.
    return value.replace("_", " ").upper() if value else "-"

def _parse_iso_ts(value: Any) -> float:
    if not isinstance(value, str) or not value:
        return 0.0
    v = value.strip()
    if v.endswith("Z"):
        v = v[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(v).timestamp()
    except Exception:
        return 0.0


def _machine_helmet_status(session: SessionArtifact) -> str:
    helmet = session.checklist.get("helmet")
    return str(helmet) if isinstance(helmet, str) and helmet else "UNKNOWN"


def _machine_roi_status(session: SessionArtifact) -> str:
    roi = session.checklist.get("roi_dwell")
    return str(roi) if isinstance(roi, str) and roi else "UNKNOWN"


def _normalize_step_status(value: Any) -> str:
    if not isinstance(value, str):
        return "UNKNOWN"
    v = value.strip().upper()
    if v in {"DONE", "NOT_DONE", "UNKNOWN"}:
        return v
    return "UNKNOWN"


@dataclass(frozen=True)
class EffectiveReview:
    status: Literal["QUALIFIED", "NOT_QUALIFIED", "PENDING"]
    source: Literal["MANUAL", "AUTO", "PENDING"]
    auto_reason: Optional[str] = None


def _session_duration_s(session: SessionArtifact) -> float:
    start_s = float(session.checklist.get("start_time_s") or 0.0)
    end_s = float(session.checklist.get("end_time_s") or 0.0)
    return max(0.0, end_s - start_s)


def _auto_approve_blocker(notes: Any) -> Optional[str]:
    if not isinstance(notes, list):
        return None
    for raw in notes:
        if not isinstance(raw, str):
            continue
        tag = raw.strip().lower()
        if not tag:
            continue
        if ("too_short" in tag) or ("too_small" in tag) or ("disabled" in tag):
            return tag
    return None


def _should_auto_approve_session(*, session: SessionArtifact, settings: WebMvpSettings) -> tuple[bool, Optional[str]]:
    if not settings.auto_approve_done_enabled:
        return False, "auto_approve_disabled"

    helmet = _normalize_step_status(_machine_helmet_status(session))
    if helmet != "DONE":
        return False, "helmet_not_done"

    roi = _normalize_step_status(_machine_roi_status(session))
    if roi != "DONE":
        return False, "roi_not_done"

    duration_s = _session_duration_s(session)
    if duration_s < float(settings.auto_approve_min_duration_s):
        return False, "duration_too_short"

    blocker = _auto_approve_blocker(session.checklist.get("notes"))
    if blocker:
        return False, f"blocked_by_note:{blocker}"

    has_evidence = _clip_count(session) > 0 or session.paths.thumbnail_jpg.exists()
    if not has_evidence:
        return False, "no_evidence"

    return True, "policy_pass"


def _effective_review_for_session(
    *,
    session: SessionArtifact,
    review: Optional[ReviewRecord],
    settings: WebMvpSettings,
) -> EffectiveReview:
    if review is not None:
        manual_status = str(review.review_status).upper()
        if manual_status == "QUALIFIED":
            return EffectiveReview(status="QUALIFIED", source="MANUAL")
        if manual_status == "NOT_QUALIFIED":
            return EffectiveReview(status="NOT_QUALIFIED", source="MANUAL")
        return EffectiveReview(status="PENDING", source="MANUAL")

    allow_auto, reason = _should_auto_approve_session(session=session, settings=settings)
    if allow_auto:
        return EffectiveReview(status="QUALIFIED", source="AUTO", auto_reason=reason)
    return EffectiveReview(status="PENDING", source="PENDING", auto_reason=reason)


def _clip_count(session: SessionArtifact) -> int:
    clips = session.evidence.get("clips")
    if isinstance(clips, list):
        return len(clips)
    return 0


def _first_clip_rel_file(session: SessionArtifact) -> Optional[str]:
    clips = session.evidence.get("clips")
    if not isinstance(clips, list) or not clips:
        return None
    clip0 = clips[0]
    if not isinstance(clip0, dict):
        return None
    rel_file = clip0.get("file")
    if not isinstance(rel_file, str) or not rel_file:
        return None
    # Evidence writer may emit Windows-style separators; normalize for URLs.
    return rel_file.replace("\\", "/")


def _safe_session_dir(data_dir: Path, session: SessionArtifact, rel_path: str) -> Path:
    base = session.paths.session_dir.resolve()
    target = (session.paths.session_dir / rel_path).resolve()
    if base == target:
        return target
    try:
        target.relative_to(base)
    except ValueError as e:
        raise HTTPException(status_code=400, detail="Invalid media path") from e
    return target


def _safe_rel_path(rel_path: str) -> Path:
    rel_path = rel_path.replace("\\", "/")
    p = Path(rel_path)
    if p.is_absolute():
        raise HTTPException(status_code=400, detail="Invalid rel_path (absolute)")
    if not rel_path.strip():
        raise HTTPException(status_code=400, detail="Invalid rel_path (empty)")
    parts = [part for part in p.parts if part not in (".", "")]
    if any(part == ".." for part in parts):
        raise HTTPException(status_code=400, detail="Invalid rel_path (parent traversal)")
    return Path(*parts)


def _atomic_write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


class ReviewUpsertIn(BaseModel):
    review_status: Literal["QUALIFIED", "NOT_QUALIFIED", "PENDING"] = Field(...)
    review_note: str = Field(default="")
    overrides: Dict[str, Any] = Field(default_factory=dict)


class SessionUpsertIn(BaseModel):
    model_config = ConfigDict(extra="allow")

    session_uid: str = Field(...)
    session_id: str = Field(...)
    start_date: Optional[str] = Field(default=None, description="YYYY-MM-DD; used for storage layout.")
    end_date: Optional[str] = Field(default=None, description="YYYY-MM-DD; used if start_date is missing.")


def _storage_date(payload: SessionUpsertIn) -> str:
    if payload.start_date and isinstance(payload.start_date, str):
        return payload.start_date
    if payload.end_date and isinstance(payload.end_date, str):
        return payload.end_date
    raise HTTPException(status_code=400, detail="Missing start_date/end_date (YYYY-MM-DD)")


_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")


def _validate_date_ymd(date: str) -> None:
    if not _DATE_RE.match(date):
        raise HTTPException(status_code=400, detail="Invalid date (expected YYYY-MM-DD)")


def _parse_date_ymd(date_raw: str) -> Optional[Date]:
    if not isinstance(date_raw, str):
        return None
    if not _DATE_RE.match(date_raw):
        return None
    try:
        return datetime.strptime(date_raw, "%Y-%m-%d").date()
    except Exception:
        return None


def _validate_token(value: str, *, label: str) -> None:
    if not value or not _SAFE_TOKEN_RE.match(value):
        raise HTTPException(status_code=400, detail=f"Invalid {label}")


def _validate_session_uid(session_uid: str) -> None:
    # We generate uuid4 hex today; accept safe tokens so we can evolve later.
    _validate_token(session_uid, label="session_uid")


def _validate_session_id(session_id: str) -> None:
    _validate_token(session_id, label="session_id")


def _resolve_date_window(
    *,
    date: Optional[str],
    date_from: Optional[str],
    date_to: Optional[str],
) -> tuple[Optional[Date], Optional[Date], Optional[str], Optional[str]]:
    if date and (date_from or date_to):
        raise HTTPException(status_code=400, detail="Use either `date` or `date_from/date_to`, not both")
    if date:
        _validate_date_ymd(date)
        d = _parse_date_ymd(date)
        if d is None:
            raise HTTPException(status_code=400, detail="Invalid date (expected YYYY-MM-DD)")
        return d, d, date, date
    if date_from:
        _validate_date_ymd(date_from)
    if date_to:
        _validate_date_ymd(date_to)
    from_d = _parse_date_ymd(date_from) if date_from else None
    to_d = _parse_date_ymd(date_to) if date_to else None
    if date_from and from_d is None:
        raise HTTPException(status_code=400, detail="Invalid `date_from` (expected YYYY-MM-DD)")
    if date_to and to_d is None:
        raise HTTPException(status_code=400, detail="Invalid `date_to` (expected YYYY-MM-DD)")
    if from_d and to_d and from_d > to_d:
        raise HTTPException(status_code=400, detail="Invalid date range (`date_from` > `date_to`)")
    return from_d, to_d, date_from, date_to


def _filter_sessions_by_date_window(
    sessions: List[SessionArtifact],
    *,
    date: Optional[str],
    date_from: Optional[str],
    date_to: Optional[str],
) -> tuple[List[SessionArtifact], Optional[str], Optional[str]]:
    lower, upper, lower_raw, upper_raw = _resolve_date_window(date=date, date_from=date_from, date_to=date_to)
    if lower or upper:
        filtered: List[SessionArtifact] = []
        for session in sessions:
            session_date = _parse_date_ymd(session.date)
            if session_date is None:
                # Ignore invalid folder date when explicit date filtering is requested.
                continue
            if lower and session_date < lower:
                continue
            if upper and session_date > upper:
                continue
            filtered.append(session)
        sessions = filtered
    return sessions, lower_raw, upper_raw


def create_app(settings: WebMvpSettings) -> FastAPI:
    init_db(settings.db_path)
    index = SessionIndex(data_dir=settings.data_dir)

    app = FastAPI(title="SOP Review MVP", version="0.1.0")
    auth_cfg = BasicAuthConfig(username=settings.admin_username, password=settings.admin_password)
    app.add_middleware(
        BasicAuthMiddleware,
        cfg=auth_cfg,
    )

    ui_dir = settings.ui_dir
    app.mount("/ui", StaticFiles(directory=str(ui_dir), html=True), name="ui")

    @app.on_event("startup")
    def _startup() -> None:
        index.refresh()

    @app.get("/", include_in_schema=False)
    def _root() -> RedirectResponse:
        return RedirectResponse(url="/ui/index.html")

    @app.get("/api/health")
    def health() -> Dict[str, str]:
        return {"status": "ok"}

    class LoginIn(BaseModel):
        username: str = Field(...)
        password: str = Field(...)

    @app.post("/api/auth/login")
    def login(payload: LoginIn) -> JSONResponse:
        if not settings.admin_password:
            raise HTTPException(status_code=400, detail="Auth disabled (no admin password configured)")
        if payload.username != settings.admin_username or payload.password != settings.admin_password:
            raise HTTPException(status_code=401, detail="Invalid credentials")

        token = issue_session_token(cfg=auth_cfg, username=settings.admin_username)
        resp = JSONResponse({"status": "ok"})
        resp.set_cookie(
            key=auth_cfg.cookie_name,
            value=token,
            max_age=int(auth_cfg.cookie_max_age_s),
            httponly=True,
            samesite="lax",
            path="/",
        )
        return resp

    @app.post("/api/auth/logout")
    def logout() -> JSONResponse:
        resp = JSONResponse({"status": "ok"})
        resp.delete_cookie(key=auth_cfg.cookie_name, path="/")
        return resp

    @app.post("/api/admin/rescan")
    def rescan() -> Dict[str, str]:
        index.refresh()
        return {
            "status": "ok",
            "last_scan_utc": index.last_scan_utc or "",
            "session_count": str(len(index.list())),
        }

    @app.get("/api/config")
    def config() -> Dict[str, Any]:
        return {
            "data_dir": str(settings.data_dir),
            "db_path": str(settings.db_path),
            "last_scan_utc": index.last_scan_utc,
            "session_count": len(index.list()),
            "auto_approve_done_enabled": settings.auto_approve_done_enabled,
            "auto_approve_min_duration_s": settings.auto_approve_min_duration_s,
        }

    @app.get("/api/stats")
    def stats(
        *,
        date: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> Dict[str, Any]:
        sessions = index.list()
        sessions, applied_date_from, applied_date_to = _filter_sessions_by_date_window(
            sessions,
            date=date,
            date_from=date_from,
            date_to=date_to,
        )
        reviews = get_reviews_by_uid(settings.db_path, (s.session_uid for s in sessions))
        pending = 0
        approved = 0
        rejected = 0
        decided = 0
        human_reviewed = 0
        auto_approved = 0
        manual_overrides = 0
        manual_helmet_overrides = 0

        machine_done = 0
        machine_not_done = 0
        machine_unknown = 0
        final_done = 0
        final_not_done = 0
        final_unknown = 0

        for s in sessions:
            r = reviews.get(s.session_uid)
            eff = _effective_review_for_session(session=s, review=r, settings=settings)
            status = eff.status
            if status == "QUALIFIED":
                approved += 1
                decided += 1
            elif status == "NOT_QUALIFIED":
                rejected += 1
                decided += 1
            else:
                pending += 1

            machine_helmet = _normalize_step_status(_machine_helmet_status(s))
            if machine_helmet == "DONE":
                machine_done += 1
            elif machine_helmet == "NOT_DONE":
                machine_not_done += 1
            else:
                machine_unknown += 1

            final_helmet = machine_helmet
            if r is not None:
                human_reviewed += 1
                if r.overrides:
                    manual_overrides += 1
                override = r.overrides.get("helmet")
                if isinstance(override, str) and override:
                    final_helmet = _normalize_step_status(override)
                    if final_helmet != machine_helmet:
                        manual_helmet_overrides += 1
            elif eff.source == "AUTO" and status == "QUALIFIED":
                auto_approved += 1

            if final_helmet == "DONE":
                final_done += 1
            elif final_helmet == "NOT_DONE":
                final_not_done += 1
            else:
                final_unknown += 1

        total = len(sessions)
        review_completion_pct = (float(decided) * 100.0 / float(total)) if total > 0 else 0.0
        final_unknown_pct = (float(final_unknown) * 100.0 / float(total)) if total > 0 else 0.0
        reviewed_final_done_pct = (float(final_done) * 100.0 / float(decided)) if decided > 0 else 0.0
        return {
            "total_sessions": total,
            "pending": pending,
            "approved": approved,
            "rejected": rejected,
            # Keep `unknown` for compatibility with existing UI cards.
            "unknown": final_unknown,
            "reviewed": decided,
            "human_reviewed": human_reviewed,
            "auto_approved": auto_approved,
            "review_completion_pct": review_completion_pct,
            "manual_overrides": manual_overrides,
            "manual_helmet_overrides": manual_helmet_overrides,
            "machine_helmet_done": machine_done,
            "machine_helmet_not_done": machine_not_done,
            "machine_helmet_unknown": machine_unknown,
            "final_helmet_done": final_done,
            "final_helmet_not_done": final_not_done,
            "final_helmet_unknown": final_unknown,
            "final_unknown_pct": final_unknown_pct,
            "reviewed_final_done_pct": reviewed_final_done_pct,
            "date_from": applied_date_from,
            "date_to": applied_date_to,
        }

    @app.get("/api/sessions")
    def list_sessions(
        *,
        date: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        review_status: Optional[Literal["QUALIFIED", "NOT_QUALIFIED", "PENDING"]] = None,
        sort: Literal["NEWEST", "OLDEST", "MACHINE_UNKNOWN_FIRST", "PENDING_FIRST"] = Query(default="NEWEST"),
        limit: int = Query(default=200, ge=1, le=2000),
    ) -> Dict[str, Any]:
        sessions = index.list()
        sessions, applied_date_from, applied_date_to = _filter_sessions_by_date_window(
            sessions,
            date=date,
            date_from=date_from,
            date_to=date_to,
        )
        reviews = get_reviews_by_uid(settings.db_path, (s.session_uid for s in sessions))
        out: List[Dict[str, Any]] = []
        for s in sessions:
            r = reviews.get(s.session_uid)
            eff = _effective_review_for_session(session=s, review=r, settings=settings)
            rs = eff.status
            if review_status and rs != review_status:
                continue

            start_iso = s.checklist.get("start_time_iso")
            end_iso = s.checklist.get("end_time_iso")
            start_s = float(s.checklist.get("start_time_s") or 0.0)
            end_s = float(s.checklist.get("end_time_s") or 0.0)
            duration_s = max(0.0, end_s - start_s)
            start_ts = _parse_iso_ts(start_iso) or _parse_iso_ts(end_iso)

            machine = _machine_helmet_status(s)
            final = machine
            if r is not None:
                override = r.overrides.get("helmet")
                if isinstance(override, str) and override:
                    final = override

            out.append(
                {
                    "session_uid": s.session_uid,
                    "date": s.date,
                    "session_id": s.session_id,
                    "start_time_iso": start_iso,
                    "end_time_iso": end_iso,
                    "duration_s": duration_s,
                    "machine_helmet": machine,
                    "machine_roi_dwell": _machine_roi_status(s),
                    "review_status": rs,
                    "review_source": eff.source,
                    "final_helmet": final,
                    "has_thumbnail": s.paths.thumbnail_jpg.exists(),
                    "thumbnail_url": f"/media/{s.session_uid}/thumbnail.jpg" if s.paths.thumbnail_jpg.exists() else None,
                    "clip_count": _clip_count(s),
                    "first_clip_url": (
                        f"/media/{s.session_uid}/{_first_clip_rel_file(s)}" if _first_clip_rel_file(s) else None
                    ),
                    "_sort_start_ts": start_ts,
                }
            )

        if sort == "OLDEST":
            out.sort(key=lambda x: (float(x.get("_sort_start_ts") or 0.0), str(x.get("session_uid") or "")))
        elif sort == "MACHINE_UNKNOWN_FIRST":
            out.sort(
                key=lambda x: (
                    0 if str(x.get("machine_helmet") or "").upper() == "UNKNOWN" else 1,
                    -float(x.get("_sort_start_ts") or 0.0),
                    str(x.get("session_uid") or ""),
                )
            )
        elif sort == "PENDING_FIRST":
            out.sort(
                key=lambda x: (
                    0 if str(x.get("review_status") or "").upper() == "PENDING" else 1,
                    -float(x.get("_sort_start_ts") or 0.0),
                    str(x.get("session_uid") or ""),
                )
            )
        else:
            out.sort(key=lambda x: (-float(x.get("_sort_start_ts") or 0.0), str(x.get("session_uid") or "")))

        out = out[:limit]
        for row in out:
            row.pop("_sort_start_ts", None)
        return {
            "sessions": out,
            "last_scan_utc": index.last_scan_utc,
            "date_from": applied_date_from,
            "date_to": applied_date_to,
        }

    @app.get("/api/sessions/{session_uid}")
    def get_session(session_uid: str) -> Dict[str, Any]:
        _validate_session_uid(session_uid)
        s = index.get(session_uid)
        if s is None:
            raise HTTPException(status_code=404, detail="Session not found")
        r = get_review(settings.db_path, session_uid)
        eff = _effective_review_for_session(session=s, review=r, settings=settings)
        machine_helmet = _machine_helmet_status(s)
        final_helmet = machine_helmet
        if r is not None:
            override = r.overrides.get("helmet")
            if isinstance(override, str) and override:
                final_helmet = override

        clips: List[Dict[str, Any]] = []
        if isinstance(s.evidence.get("clips"), list):
            for clip in s.evidence["clips"]:
                if not isinstance(clip, dict):
                    continue
                rel_file = clip.get("file")
                if not isinstance(rel_file, str) or not rel_file:
                    continue
                rel_file = rel_file.replace("\\", "/")
                clips.append(
                    {
                        **clip,
                        "url": f"/media/{s.session_uid}/{rel_file}",
                    }
                )

        artifacts: List[Dict[str, str]] = []
        for rel in ("checklist.json", "run_config.json", "thumbnail.jpg", "evidence.json"):
            p = s.paths.session_dir / rel
            if p.exists():
                artifacts.append({"name": rel, "url": f"/media/{s.session_uid}/{rel}"})
        if (s.paths.session_dir / "evidence").exists():
            for mp4 in sorted((s.paths.session_dir / "evidence").glob("*.mp4")):
                rel = str(mp4.relative_to(s.paths.session_dir))
                artifacts.append({"name": rel, "url": f"/media/{s.session_uid}/{rel}"})

        return {
            "session_uid": s.session_uid,
            "date": s.date,
            "session_id": s.session_id,
            "checklist": s.checklist,
            "machine_helmet": machine_helmet,
            "machine_roi_dwell": _machine_roi_status(s),
            "final_helmet": final_helmet,
            "review_status": eff.status,
            "review_source": eff.source,
            "auto_review_reason": eff.auto_reason,
            "review": None if r is None else r.__dict__,
            "clips": clips,
            "has_thumbnail": s.paths.thumbnail_jpg.exists(),
            "thumbnail_url": f"/media/{s.session_uid}/thumbnail.jpg" if s.paths.thumbnail_jpg.exists() else None,
            "artifacts": artifacts,
        }

    @app.put("/api/sessions/{session_uid}")
    def put_session(session_uid: str, payload: SessionUpsertIn) -> Dict[str, Any]:
        if payload.session_uid != session_uid:
            raise HTTPException(status_code=400, detail="session_uid mismatch")

        date = _storage_date(payload)
        _validate_session_uid(session_uid)
        _validate_session_id(payload.session_id)
        _validate_date_ymd(date)

        # In ingestion mode, store by UID to avoid collisions across devices/runs.
        session_dir = settings.data_dir / "sessions" / date / session_uid
        session_dir.mkdir(parents=True, exist_ok=True)

        checklist_path = session_dir / "checklist.json"
        _atomic_write_json(checklist_path, payload.model_dump(mode="json"))

        index.refresh()
        return {
            "status": "ok",
            "session_uid": session_uid,
            "date": date,
            "session_id": payload.session_id,
        }

    @app.put("/api/sessions/{session_uid}/review")
    def put_review(session_uid: str, payload: ReviewUpsertIn) -> Dict[str, Any]:
        _validate_session_uid(session_uid)
        s = index.get(session_uid)
        if s is None:
            raise HTTPException(status_code=404, detail="Session not found")
        rec = upsert_review(
            db_path=settings.db_path,
            session_uid=session_uid,
            review_status=payload.review_status,
            review_note=payload.review_note,
            overrides=payload.overrides,
        )
        return {"review": rec.__dict__}

    @app.post("/api/sessions/{session_uid}/artifacts")
    async def post_artifact(
        session_uid: str,
        request: Request,
        rel_path: str = Query(..., description="Relative path under the session dir, e.g. evidence/helmet_done_01.mp4"),
    ) -> Dict[str, Any]:
        _validate_session_uid(session_uid)
        s = index.get(session_uid)
        if s is None:
            # Allow for eventual consistency (client may upload fast after upsert).
            index.refresh()
            s = index.get(session_uid)
        if s is None:
            raise HTTPException(status_code=404, detail="Session not found (upsert first)")

        rel = _safe_rel_path(rel_path)
        base = s.paths.session_dir.resolve()
        target = (s.paths.session_dir / rel).resolve()
        try:
            target.relative_to(base)
        except ValueError as e:
            raise HTTPException(status_code=400, detail="Invalid rel_path") from e

        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_suffix(target.suffix + ".tmp")
        with tmp.open("wb") as f:
            async for chunk in request.stream():
                if chunk:
                    f.write(chunk)
        tmp.replace(target)

        # Refresh index so evidence/thumbnail manifests show immediately.
        index.refresh()

        rel_url = str(rel).replace("\\", "/")
        return {
            "status": "ok",
            "rel_path": rel_url,
            "url": f"/media/{session_uid}/{rel_url}",
        }

    @app.get("/media/{session_uid}/{rel_path:path}", include_in_schema=False)
    def media(session_uid: str, rel_path: str) -> FileResponse:
        _validate_session_uid(session_uid)
        s = index.get(session_uid)
        if s is None:
            raise HTTPException(status_code=404, detail="Session not found")
        target = _safe_session_dir(settings.data_dir, s, rel_path)
        if not target.exists() or not target.is_file():
            raise HTTPException(status_code=404, detail="File not found")
        return FileResponse(str(target))

    return app
